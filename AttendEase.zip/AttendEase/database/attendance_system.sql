-- AttendEase - Student Attendance and Shortage Calculator
-- Database Schema & Sample Seed Data
-- Database Name: attendance_system

CREATE DATABASE IF NOT EXISTS `attendance_system` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `attendance_system`;

-- --------------------------------------------------------
-- Table: departments
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `departments` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `dept_code` VARCHAR(20) NOT NULL UNIQUE,
    `dept_name` VARCHAR(100) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: semesters
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `semesters` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `semester_number` INT NOT NULL UNIQUE,
    `semester_name` VARCHAR(50) NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: users
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `role` ENUM('student', 'admin') NOT NULL DEFAULT 'student',
    `name` VARCHAR(100) NOT NULL,
    `register_number` VARCHAR(50) NULL UNIQUE,
    `email` VARCHAR(150) NOT NULL UNIQUE,
    `password_hash` VARCHAR(255) NOT NULL,
    `department_id` INT NULL,
    `year_of_study` INT NULL,
    `semester_id` INT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_users_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_users_semester` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE SET NULL,
    INDEX `idx_users_role` (`role`),
    INDEX `idx_users_email` (`email`),
    INDEX `idx_users_regno` (`register_number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: subjects
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `subjects` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `subject_code` VARCHAR(20) NOT NULL,
    `subject_name` VARCHAR(150) NOT NULL,
    `faculty_name` VARCHAR(100) NOT NULL,
    `department_id` INT NOT NULL,
    `semester_id` INT NOT NULL,
    `required_percentage` DECIMAL(5, 2) NOT NULL DEFAULT 75.00,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_subjects_department` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_subjects_semester` FOREIGN KEY (`semester_id`) REFERENCES `semesters` (`id`) ON DELETE CASCADE,
    UNIQUE KEY `uk_dept_sem_subj` (`department_id`, `semester_id`, `subject_code`),
    INDEX `idx_subjects_code` (`subject_code`),
    INDEX `idx_subjects_dept` (`department_id`),
    INDEX `idx_subjects_sem` (`semester_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: student_subjects
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `student_subjects` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `student_id` INT NOT NULL,
    `subject_id` INT NOT NULL,
    `enrolled_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT `fk_ss_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_ss_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
    UNIQUE KEY `uk_student_subject` (`student_id`, `subject_id`),
    INDEX `idx_ss_student` (`student_id`),
    INDEX `idx_ss_subject` (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- Table: attendance_records
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `attendance_records` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `student_id` INT NOT NULL,
    `subject_id` INT NOT NULL,
    `classes_conducted` INT NOT NULL DEFAULT 0,
    `classes_attended` INT NOT NULL DEFAULT 0,
    `last_updated` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_ar_student` FOREIGN KEY (`student_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_ar_subject` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`id`) ON DELETE CASCADE,
    UNIQUE KEY `uk_student_subject_attendance` (`student_id`, `subject_id`),
    INDEX `idx_ar_student` (`student_id`),
    INDEX `idx_ar_subject` (`subject_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------
-- SEED DATA
-- --------------------------------------------------------

-- Insert Departments
INSERT INTO `departments` (`id`, `dept_code`, `dept_name`) VALUES
(1, 'CSE', 'Computer Science and Engineering'),
(2, 'IT', 'Information Technology'),
(3, 'ECE', 'Electronics and Communication Engineering'),
(4, 'MECH', 'Mechanical Engineering')
ON DUPLICATE KEY UPDATE `dept_name` = VALUES(`dept_name`);

-- Insert Semesters (1 to 8)
INSERT INTO `semesters` (`id`, `semester_number`, `semester_name`) VALUES
(1, 1, 'Semester 1'),
(2, 2, 'Semester 2'),
(3, 3, 'Semester 3'),
(4, 4, 'Semester 4'),
(5, 5, 'Semester 5'),
(6, 6, 'Semester 6'),
(7, 7, 'Semester 7'),
(8, 8, 'Semester 8')
ON DUPLICATE KEY UPDATE `semester_name` = VALUES(`semester_name`);

-- Insert Administrator Account
-- Credentials: admin@attendease.edu / AdminPassword123!
-- Note: password_hash for 'AdminPassword123!' generated using PASSWORD_BCRYPT
INSERT INTO `users` (`id`, `role`, `name`, `register_number`, `email`, `password_hash`, `department_id`, `year_of_study`, `semester_id`) VALUES
(1, 'admin', 'System Administrator', 'ADMIN001', 'admin@attendease.edu', '$2y$10$wT/7zZ0YgK8k8d6a8b7U1OKw2Z3X4Y5Z6A7B8C9D0E1F2G3H4I5J6', NULL, NULL, NULL)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- Insert Sample Student 1
-- Credentials: student@attendease.edu / StudentPassword123!
-- Register Number: REG2026CS101 (Semester 5 CSE)
INSERT INTO `users` (`id`, `role`, `name`, `register_number`, `email`, `password_hash`, `department_id`, `year_of_study`, `semester_id`) VALUES
(2, 'student', 'Alex Johnson', 'REG2026CS101', 'student@attendease.edu', '$2y$10$wT/7zZ0YgK8k8d6a8b7U1OKw2Z3X4Y5Z6A7B8C9D0E1F2G3H4I5J6', 1, 3, 5)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- Insert Sample Student 2 (Student with acute attendance shortage)
-- Register Number: REG2026CS102 (Semester 5 CSE)
INSERT INTO `users` (`id`, `role`, `name`, `register_number`, `email`, `password_hash`, `department_id`, `year_of_study`, `semester_id`) VALUES
(3, 'student', 'Priya Sharma', 'REG2026CS102', 'priya@attendease.edu', '$2y$10$wT/7zZ0YgK8k8d6a8b7U1OKw2Z3X4Y5Z6A7B8C9D0E1F2G3H4I5J6', 1, 3, 5)
ON DUPLICATE KEY UPDATE `name` = VALUES(`name`);

-- Insert Sample Subjects for Semester 5 CSE
INSERT INTO `subjects` (`id`, `subject_code`, `subject_name`, `faculty_name`, `department_id`, `semester_id`, `required_percentage`) VALUES
(1, 'CS501', 'Database Management Systems', 'Dr. Edgar Codd', 1, 5, 75.00),
(2, 'CS502', 'Operating Systems', 'Prof. Andrew Tanenbaum', 1, 5, 75.00),
(3, 'CS503', 'Computer Networks', 'Dr. Vinton Cerf', 1, 5, 80.00),
(4, 'CS504', 'Theory of Computation', 'Prof. Michael Sipser', 1, 5, 75.00),
(5, 'CS505', 'Software Engineering', 'Dr. Margaret Hamilton', 1, 5, 75.00),
(6, 'CS506', 'Cloud Computing Lab', 'Prof. John McCarthy', 1, 5, 75.00)
ON DUPLICATE KEY UPDATE `subject_name` = VALUES(`subject_name`);

-- Enroll Alex Johnson (Student ID 2) in Semester 5 Subjects
INSERT INTO `student_subjects` (`student_id`, `subject_id`) VALUES
(2, 1),
(2, 2),
(2, 3),
(2, 4),
(2, 5),
(2, 6)
ON DUPLICATE KEY UPDATE `subject_id` = VALUES(`subject_id`);

-- Alex Johnson Attendance Records (Edge cases & diverse attendance states)
-- CS501: Conducted 40, Attended 32 -> 80.00% (SAFE, req 75%)
-- CS502: Conducted 36, Attended 24 -> 66.67% (SHORTAGE, req 75%)
-- CS503: Conducted 45, Attended 38 -> 84.44% (SAFE, req 80%)
-- CS504: Conducted 30, Attended 18 -> 60.00% (SHORTAGE, req 75%)
-- CS505: Conducted 28, Attended 28 -> 100.00% (SAFE, req 75%)
-- CS506: Conducted 0, Attended 0   -> 0.00% (NO CLASSES, initial state)
INSERT INTO `attendance_records` (`student_id`, `subject_id`, `classes_conducted`, `classes_attended`) VALUES
(2, 1, 40, 32),
(2, 2, 36, 24),
(2, 3, 45, 38),
(2, 4, 30, 18),
(2, 5, 28, 28),
(2, 6, 0, 0)
ON DUPLICATE KEY UPDATE 
    `classes_conducted` = VALUES(`classes_conducted`),
    `classes_attended` = VALUES(`classes_attended`);

-- Enroll Priya Sharma (Student ID 3) in Semester 5 Subjects
INSERT INTO `student_subjects` (`student_id`, `subject_id`) VALUES
(3, 1),
(3, 2),
(3, 3),
(3, 4),
(3, 5),
(3, 6)
ON DUPLICATE KEY UPDATE `subject_id` = VALUES(`subject_id`);

-- Priya Sharma Attendance Records (Severe Shortages)
-- CS501: Conducted 40, Attended 20 -> 50.00% (SHORTAGE)
-- CS502: Conducted 36, Attended 18 -> 50.00% (SHORTAGE)
-- CS503: Conducted 45, Attended 25 -> 55.56% (SHORTAGE, req 80%)
-- CS504: Conducted 30, Attended 15 -> 50.00% (SHORTAGE)
-- CS505: Conducted 28, Attended 14 -> 50.00% (SHORTAGE)
-- CS506: Conducted 0, Attended 0   -> 0.00% (NO CLASSES)
INSERT INTO `attendance_records` (`student_id`, `subject_id`, `classes_conducted`, `classes_attended`) VALUES
(3, 1, 40, 20),
(3, 2, 36, 18),
(3, 3, 45, 25),
(3, 4, 30, 15),
(3, 5, 28, 14),
(3, 6, 0, 0)
ON DUPLICATE KEY UPDATE 
    `classes_conducted` = VALUES(`classes_conducted`),
    `classes_attended` = VALUES(`classes_attended`);
