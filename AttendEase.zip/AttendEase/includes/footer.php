<?php
/**
 * AttendEase - Footer Template
 * 
 * Closes the layout wrappers and displays academic footer notes.
 */

declare(strict_types=1);

$isAuthPage = !empty($is_auth_page);
?>
<?php if ($isAuthPage): ?>
    </main>
<?php else: ?>
            </main>
        </div>
    </div>
<?php endif; ?>

</body>
</html>
