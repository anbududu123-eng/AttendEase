<?php
/**
 * AttendEase - Header Template
 * 
 * Renders HTML5 doctype, meta tags, compiled CSS stylesheet,
 * responsive mobile navigation, sidebar, top navbar, and flash alerts.
 */

declare(strict_types=1);

if (!isset($base_path)) {
    $base_path = '';
}

$pageTitle = isset($page_title) ? $page_title . ' — AttendEase' : 'AttendEase — Student Attendance and Shortage Calculator';
$currentUser = current_user();
$isAuthPage = !empty($is_auth_page);
$flash = get_flash();
$activeNav = $active_nav ?? '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?= e($pageTitle) ?></title>
    <!-- Compiled pure CSS stylesheet generated from SCSS -->
    <link rel="stylesheet" href="<?= e($base_path) ?>assets/css/style.css">
</head>
<body>

<?php if ($isAuthPage): ?>
    <!-- Non-dashboard standalone page wrapper (Login / Register / Welcome) -->
    <main class="auth-page-wrapper">
<?php else: ?>
    <!-- Pure CSS mobile sidebar toggle -->
    <input type="checkbox" id="sidebar-toggle" class="sidebar-toggle-checkbox">

    <!-- Mobile Top Navigation Header -->
    <header class="mobile-header-bar">
        <a href="<?= e($base_path) ?><?= ($currentUser && $currentUser['role'] === 'admin') ? 'admin/dashboard.php' : 'dashboard.php' ?>" class="mobile-brand">
            AttendEase
        </a>
        <label for="sidebar-toggle" class="sidebar-toggle-label" title="Toggle Navigation Menu">&#9776;</label>
    </header>

    <div class="app-wrapper">
        <!-- Application Sidebar Navigation -->
        <aside class="app-sidebar">
            <div class="sidebar-header">
                <a href="<?= e($base_path) ?><?= ($currentUser && $currentUser['role'] === 'admin') ? 'admin/dashboard.php' : 'dashboard.php' ?>" class="brand-link">
                    <div class="brand-logo-badge">A</div>
                    <div class="brand-text">
                        <span class="brand-title">AttendEase</span>
                        <span class="brand-subtitle">Attendance & Shortage</span>
                    </div>
                </a>
            </div>

            <?php if ($currentUser): ?>
            <div class="sidebar-user">
                <div class="user-name"><?= e($currentUser['name']) ?></div>
                <div class="user-meta">
                    <?php if ($currentUser['role'] === 'student'): ?>
                        <span><?= e($currentUser['register_number'] ?? 'Student') ?></span>
                        <?php if (!empty($currentUser['dept_code'])): ?>
                            &bull; <span><?= e($currentUser['dept_code']) ?></span>
                        <?php endif; ?>
                    <?php else: ?>
                        <span><?= e($currentUser['email']) ?></span>
                    <?php endif; ?>
                </div>
                <span class="role-pill"><?= e($currentUser['role']) ?></span>
            </div>
            <?php endif; ?>

            <nav class="sidebar-nav">
                <?php if ($currentUser && $currentUser['role'] === 'admin'): ?>
                    <!-- Admin Navigation Links -->
                    <div class="nav-section-title">Administration</div>
                    <ul class="nav-list">
                        <li class="nav-item">
                            <a href="<?= e($base_path) ?>admin/dashboard.php" class="nav-link <?= ($activeNav === 'admin_dashboard') ? 'active' : '' ?>">
                                <span class="nav-icon">&#128202;</span>
                                <span>Overview</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= e($base_path) ?>admin/students.php" class="nav-link <?= ($activeNav === 'admin_students') ? 'active' : '' ?>">
                                <span class="nav-icon">&#127891;</span>
                                <span>Students Directory</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= e($base_path) ?>admin/manage_subjects.php" class="nav-link <?= ($activeNav === 'admin_subjects') ? 'active' : '' ?>">
                                <span class="nav-icon">&#128218;</span>
                                <span>Manage Subjects</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= e($base_path) ?>admin/manage_attendance.php" class="nav-link <?= ($activeNav === 'admin_attendance') ? 'active' : '' ?>">
                                <span class="nav-icon">&#128221;</span>
                                <span>Manage Attendance</span>
                            </a>
                        </li>
                    </ul>
                <?php else: ?>
                    <!-- Student Navigation Links -->
                    <div class="nav-section-title">Academic Portal</div>
                    <ul class="nav-list">
                        <li class="nav-item">
                            <a href="<?= e($base_path) ?>dashboard.php" class="nav-link <?= ($activeNav === 'dashboard') ? 'active' : '' ?>">
                                <span class="nav-icon">&#128200;</span>
                                <span>Dashboard</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= e($base_path) ?>subjects.php" class="nav-link <?= ($activeNav === 'subjects') ? 'active' : '' ?>">
                                <span class="nav-icon">&#128218;</span>
                                <span>Enrolled Subjects</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= e($base_path) ?>attendance.php" class="nav-link <?= ($activeNav === 'attendance') ? 'active' : '' ?>">
                                <span class="nav-icon">&#9997;</span>
                                <span>Log Attendance</span>
                            </a>
                        </li>
                    </ul>

                    <div class="nav-section-title">Calculators & Tools</div>
                    <ul class="nav-list">
                        <li class="nav-item">
                            <a href="<?= e($base_path) ?>shortage_calculator.php" class="nav-link <?= ($activeNav === 'shortage_calculator') ? 'active' : '' ?>">
                                <span class="nav-icon">&#128293;</span>
                                <span>Shortage Calculator</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= e($base_path) ?>what_if_calculator.php" class="nav-link <?= ($activeNav === 'what_if') ? 'active' : '' ?>">
                                <span class="nav-icon">&#129300;</span>
                                <span>What-If Simulator</span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?= e($base_path) ?>reports.php" class="nav-link <?= ($activeNav === 'reports') ? 'active' : '' ?>">
                                <span class="nav-icon">&#128442;</span>
                                <span>Attendance Statement</span>
                            </a>
                        </li>
                    </ul>
                <?php endif; ?>

                <div class="nav-section-title">Account</div>
                <ul class="nav-list">
                    <li class="nav-item">
                        <a href="<?= e($base_path) ?>logout.php" class="nav-link">
                            <span class="nav-icon">&#128682;</span>
                            <span>Sign Out</span>
                        </a>
                    </li>
                </ul>
            </nav>

            <div class="sidebar-footer">
                AttendEase Academic Suite v2.0
            </div>
        </aside>

        <!-- Main Body Area -->
        <div class="app-main">
            <!-- Top Navbar for Desktop -->
            <header class="top-navbar no-print">
                <div class="page-header-title">
                    <?= e($page_title ?? 'Dashboard') ?>
                </div>
                <div class="top-navbar-actions">
                    <?php if ($currentUser): ?>
                        <div class="user-quick-info">
                            Signed in as <span><?= e($currentUser['name']) ?></span>
                            (<?= e(ucfirst($currentUser['role'])) ?>)
                        </div>
                        <a href="<?= e($base_path) ?>logout.php" class="btn btn-secondary btn-sm">Sign Out</a>
                    <?php endif; ?>
                </div>
            </header>

            <!-- Main Content Container -->
            <main class="content-container">
                <?php if ($flash): ?>
                    <div class="alert alert-<?= e($flash['type'] === 'error' ? 'error' : ($flash['type'] === 'success' ? 'success' : 'info')) ?>">
                        <span class="alert-icon">
                            <?= ($flash['type'] === 'error') ? '&#9888;' : (($flash['type'] === 'success') ? '&#10004;' : '&#8505;') ?>
                        </span>
                        <div class="alert-content">
                            <?= e($flash['message']) ?>
                        </div>
                    </div>
                <?php endif; ?>
<?php endif; ?>
