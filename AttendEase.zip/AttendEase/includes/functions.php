<?php
/**
 * AttendEase - Core Functions and Calculation Engine
 * 
 * Provides calculation algorithms, validation helpers, formatting,
 * and security functions used throughout AttendEase.
 */

declare(strict_types=1);

/**
 * Escapes HTML entities for secure output.
 *
 * @param mixed $value
 * @return string
 */
function e(mixed $value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}

/**
 * Generates a CSRF token and stores it in the active session.
 *
 * @return string
 */
function csrf_token(): string
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * Renders a hidden CSRF token input field.
 *
 * @return string
 */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

/**
 * Verifies the submitted CSRF token against the session token.
 *
 * @param string|null $token
 * @return bool
 */
function verify_csrf_token(?string $token): bool
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (empty($token) || empty($_SESSION['csrf_token'])) {
        return false;
    }
    return hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * Sets a flash message to be displayed on the next request.
 *
 * @param string $type 'success' | 'error' | 'warning' | 'info'
 * @param string $message
 * @return void
 */
function set_flash(string $type, string $message): void
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    $_SESSION['flash'] = [
        'type'    => $type,
        'message' => $message,
    ];
}

/**
 * Retrieves and clears the current flash message.
 *
 * @return array|null
 */
function get_flash(): ?array
{
    if (session_status() === PHP_SESSION_NONE) {
        session_start();
    }
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
 * Calculates current attendance percentage.
 *
 * @param int $attended
 * @param int $conducted
 * @return float
 */
function calculate_percentage(int $attended, int $conducted): float
{
    if ($conducted <= 0) {
        return 0.0;
    }
    return round(($attended / $conducted) * 100, 2);
}

/**
 * Determines attendance status label.
 *
 * @param int $attended
 * @param int $conducted
 * @param float $requiredPercentage
 * @return string 'SAFE' | 'SHORTAGE' | 'NO CLASSES'
 */
function get_attendance_status(int $attended, int $conducted, float $requiredPercentage = 75.0): string
{
    if ($conducted <= 0) {
        return 'NO CLASSES';
    }
    $pct = calculate_percentage($attended, $conducted);
    return ($pct >= $requiredPercentage) ? 'SAFE' : 'SHORTAGE';
}

/**
 * Attendance Shortage and Buffer Calculator Engine (Module 6)
 *
 * Implements the formula:
 * Minimum additional classes = CEILING((R * C - A) / (1 - R))
 *
 * @param int $attended Classes attended (A)
 * @param int $conducted Classes conducted (C)
 * @param float $requiredPercentage Required threshold percentage (e.g. 75.0)
 * @return array
 */
function calculate_shortage(int $attended, int $conducted, float $requiredPercentage = 75.0): array
{
    $A = max(0, $attended);
    $C = max(0, $conducted);
    $reqPct = (float)$requiredPercentage;
    $R = $reqPct / 100.0;

    $absent = max(0, $C - $A);
    $currentPct = calculate_percentage($A, $C);

    // Initial state: No classes conducted yet
    if ($C === 0) {
        return [
            'status'                  => 'NO CLASSES',
            'attended'                => 0,
            'conducted'               => 0,
            'absent'                  => 0,
            'current_percentage'      => 0.0,
            'required_percentage'     => $reqPct,
            'classes_needed'          => 0,
            'projected_attended'      => 0,
            'projected_conducted'     => 0,
            'projected_percentage'    => 0.0,
            'buffer_missable_classes' => 0,
            'projected_miss_pct'      => 0.0,
            'is_impossible_100'       => false,
            'message'                 => 'No classes have been conducted yet. Attendance cannot be calculated until classes begin.',
        ];
    }

    // Attendance is currently SAFE (meets or exceeds requirement)
    if ($currentPct >= $reqPct) {
        // Calculate how many future consecutive classes can be safely missed (Buffer classes)
        // Formula: M <= (A - R * C) / R = (A / R) - C
        $buffer = 0;
        $projectedMissPct = $currentPct;
        if ($R > 0) {
            $buffer = (int) floor(($A / $R) - $C);
            if ($buffer < 0) {
                $buffer = 0;
            }
            if ($buffer > 0) {
                $projectedMissConducted = $C + $buffer;
                $projectedMissPct = round(($A / $projectedMissConducted) * 100, 2);
            }
        }

        return [
            'status'                  => 'SAFE',
            'attended'                => $A,
            'conducted'               => $C,
            'absent'                  => $absent,
            'current_percentage'      => $currentPct,
            'required_percentage'     => $reqPct,
            'classes_needed'          => 0,
            'projected_attended'      => $A,
            'projected_conducted'     => $C,
            'projected_percentage'    => $currentPct,
            'buffer_missable_classes' => $buffer,
            'projected_miss_pct'      => $projectedMissPct,
            'is_impossible_100'       => false,
            'message'                 => 'Attendance requirement satisfied.',
        ];
    }

    // Attendance is in SHORTAGE state
    // Edge case: Required percentage is 100%
    if ($R >= 1.0) {
        if ($absent > 0) {
            return [
                'status'                  => 'SHORTAGE',
                'attended'                => $A,
                'conducted'               => $C,
                'absent'                  => $absent,
                'current_percentage'      => $currentPct,
                'required_percentage'     => $reqPct,
                'classes_needed'          => -1, // Flag indicating mathematically impossible
                'projected_attended'      => $A,
                'projected_conducted'     => $C,
                'projected_percentage'    => $currentPct,
                'buffer_missable_classes' => 0,
                'projected_miss_pct'      => 0.0,
                'is_impossible_100'       => true,
                'message'                 => 'The required attendance is 100%, but you have already missed ' . $absent . ' class(es). It is mathematically impossible to reach 100% attendance through future attendance alone.',
            ];
        }
    }

    // Standard Shortage calculation:
    // Minimum additional classes = CEILING((R * C - A) / (1 - R))
    $numerator = ($R * $C) - $A;
    $denominator = 1.0 - $R;
    $needed = (int) ceil($numerator / $denominator);

    if ($needed < 0) {
        $needed = 0;
    }

    // Verification step: Ensure the calculated number of classes strictly satisfies the target
    while ($needed > 0 && ((($A + $needed) / ($C + $needed)) * 100) < ($reqPct - 0.0001)) {
        $needed++;
    }

    $projectedAttended = $A + $needed;
    $projectedConducted = $C + $needed;
    $projectedPct = round(($projectedAttended / $projectedConducted) * 100, 2);

    return [
        'status'                  => 'SHORTAGE',
        'attended'                => $A,
        'conducted'               => $C,
        'absent'                  => $absent,
        'current_percentage'      => $currentPct,
        'required_percentage'     => $reqPct,
        'classes_needed'          => $needed,
        'projected_attended'      => $projectedAttended,
        'projected_conducted'     => $projectedConducted,
        'projected_percentage'    => $projectedPct,
        'buffer_missable_classes' => 0,
        'projected_miss_pct'      => 0.0,
        'is_impossible_100'       => false,
        'message'                 => 'You have an attendance shortage. You must attend the next ' . $needed . ' consecutive class(es) without absence to reach ' . number_format($reqPct, 1) . '%.',
    ];
}

/**
 * Attendance What-If Calculator (Module 7)
 * Computes hypothetical projections without altering saved database records.
 *
 * @param int $currentAttended
 * @param int $currentConducted
 * @param int $futureAttend
 * @param int $futureMiss
 * @param float $requiredPercentage
 * @return array
 */
function calculate_what_if(
    int $currentAttended,
    int $currentConducted,
    int $futureAttend,
    int $futureMiss,
    float $requiredPercentage = 75.0
): array {
    $curA = max(0, $currentAttended);
    $curC = max(0, $currentConducted);
    $futA = max(0, $futureAttend);
    $futM = max(0, $futureMiss);
    $reqPct = (float)$requiredPercentage;

    $projA = $curA + $futA;
    $projC = $curC + $futA + $futM;
    $projAbsent = max(0, $projC - $projA);

    $curPct = calculate_percentage($curA, $curC);
    $projPct = calculate_percentage($projA, $projC);
    $status = get_attendance_status($projA, $projC, $reqPct);
    $diffPct = round($projPct - $curPct, 2);

    return [
        'current_conducted'   => $curC,
        'current_attended'    => $curA,
        'current_percentage'  => $curPct,
        'future_attended'     => $futA,
        'future_missed'       => $futM,
        'projected_conducted' => $projC,
        'projected_attended'  => $projA,
        'projected_absent'    => $projAbsent,
        'projected_percentage'=> $projPct,
        'percentage_change'   => $diffPct,
        'projected_status'    => $status,
        'required_percentage' => $reqPct,
    ];
}

/**
 * Formats a percentage number with 2 decimals.
 *
 * @param float $pct
 * @return string
 */
function format_pct(float $pct): string
{
    return number_format($pct, 2) . '%';
}

/**
 * Generates relative application URL.
 *
 * @param string $path
 * @return string
 */
function app_url(string $path = ''): string
{
    // Strip leading slash for consistency
    $cleanPath = ltrim($path, '/');
    return $cleanPath;
}
