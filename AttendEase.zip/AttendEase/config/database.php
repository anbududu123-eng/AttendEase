<?php
/**
 * AttendEase - Database Connection and Initialization
 * 
 * Configures the PDO connection for MySQL with robust error handling
 * and automatic schema bootstrap if running on a fresh environment.
 */

declare(strict_types=1);

// Database connection parameters
define('DB_HOST', '127.0.0.1');
define('DB_PORT', '3306');
define('DB_NAME', 'attendance_system');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

/**
 * Returns a singleton PDO database connection instance.
 *
 * @return PDO
 * @throws PDOException
 */
function get_db_connection(): PDO
{
    static $pdo = null;

    if ($pdo !== null) {
        return $pdo;
    }

    $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=%s', DB_HOST, DB_PORT, DB_NAME, DB_CHARSET);
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
    } catch (PDOException $e) {
        // If database does not exist, attempt to auto-create and bootstrap it
        if ($e->getCode() === 1049 || str_contains($e->getMessage(), 'Unknown database')) {
            $pdo = bootstrap_database();
        } else {
            // Friendly error message for XAMPP users
            die('<div style="font-family:sans-serif;max-width:600px;margin:50px auto;padding:24px;border:1px solid #f87171;border-radius:8px;background:#fef2f2;color:#991b1b;">'
                . '<h3 style="margin-top:0;">AttendEase - Database Connection Error</h3>'
                . '<p>Unable to connect to MySQL on <code>' . htmlspecialchars(DB_HOST . ':' . DB_PORT) . '</code>.</p>'
                . '<p><strong>Troubleshooting steps for XAMPP:</strong></p>'
                . '<ol>'
                . '<li>Make sure Apache and MySQL services are started in the XAMPP Control Panel.</li>'
                . '<li>Verify that MySQL username is <code>root</code> and password is empty (default XAMPP setup).</li>'
                . '<li>If your MySQL uses a custom password or port, edit <code>config/database.php</code>.</li>'
                . '</ol>'
                . '<p><em>Technical error: ' . htmlspecialchars($e->getMessage()) . '</em></p>'
                . '</div>');
        }
    }

    return $pdo;
}

/**
 * Automatically creates the attendance_system database and seeds it from attendance_system.sql
 *
 * @return PDO
 */
function bootstrap_database(): PDO
{
    try {
        $serverDsn = sprintf('mysql:host=%s;port=%s;charset=%s', DB_HOST, DB_PORT, DB_CHARSET);
        $serverPdo = new PDO($serverDsn, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);
        
        $serverPdo->exec("CREATE DATABASE IF NOT EXISTS `" . DB_NAME . "` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        
        $dsn = sprintf('mysql:host=%s;port=%s;dbname=%s;charset=%s', DB_HOST, DB_PORT, DB_NAME, DB_CHARSET);
        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];
        if (defined('PDO::MYSQL_ATTR_MULTI_STATEMENTS')) {
            $options[PDO::MYSQL_ATTR_MULTI_STATEMENTS] = true;
        }

        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);

        $sqlFile = dirname(__DIR__) . '/database/attendance_system.sql';
        if (file_exists($sqlFile)) {
            $sql = file_get_contents($sqlFile);
            if ($sql !== false) {
                // Execute schema statements
                try {
                    $pdo->exec($sql);
                } catch (PDOException $e) {
                    // Fallback: split by semicolon and execute statement by statement
                    $statements = array_filter(array_map('trim', explode(';', $sql)));
                    foreach ($statements as $stmtSql) {
                        if ($stmtSql !== '') {
                            try {
                                $pdo->exec($stmtSql);
                            } catch (PDOException $subEx) {
                                // Continue on non-breaking statement errors
                            }
                        }
                    }
                }

                // Update default seed passwords with real dynamic hashes
                $adminPass = password_hash('AdminPassword123!', PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("UPDATE `users` SET `password_hash` = :hash WHERE `email` = 'admin@attendease.edu'");
                $stmt->execute(['hash' => $adminPass]);

                $studentPass = password_hash('StudentPassword123!', PASSWORD_BCRYPT);
                $stmt = $pdo->prepare("UPDATE `users` SET `password_hash` = :hash WHERE `email` IN ('student@attendease.edu', 'priya@attendease.edu')");
                $stmt->execute(['hash' => $studentPass]);
            }
        }

        return $pdo;
    } catch (PDOException $ex) {
        die("Fatal Database Bootstrap Error: " . htmlspecialchars($ex->getMessage()));
    }
}
