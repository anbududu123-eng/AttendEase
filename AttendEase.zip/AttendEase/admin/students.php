<?php
/**
 * AttendEase — Administrator: Student Directory & Management
 * Module 9: Add, Edit, Remove, and Search Registered Students
 */

declare(strict_types=1);

$base_path = '../';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$pdo = get_db_connection();

$departments = $pdo->query("SELECT * FROM `departments` ORDER BY `dept_name` ASC")->fetchAll();
$semesters   = $pdo->query("SELECT * FROM `semesters` ORDER BY `semester_number` ASC")->fetchAll();

$errors = [];
$editStudent = null;
$editId = (int)($_GET['edit'] ?? 0);
$action = $_GET['action'] ?? '';
$searchQuery = trim($_GET['q'] ?? '');

// If editing, load the student
if ($editId > 0) {
    $editStmt = $pdo->prepare("SELECT * FROM `users` WHERE `id` = :id AND `role` = 'student' LIMIT 1");
    $editStmt->execute(['id' => $editId]);
    $editStudent = $editStmt->fetch();
}

// Handle Form Submissions (Add / Edit / Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid session security token. Please try again.';
    } else {
        $postAction = $_POST['action'] ?? '';

        // 1. DELETE STUDENT
        if ($postAction === 'delete') {
            $deleteId = (int)($_POST['id'] ?? 0);
            if ($deleteId > 0) {
                try {
                    $delStmt = $pdo->prepare("DELETE FROM `users` WHERE `id` = :id AND `role` = 'student'");
                    $delStmt->execute(['id' => $deleteId]);
                    set_flash('success', 'Student record removed from the system successfully.');
                    header('Location: students.php');
                    exit;
                } catch (PDOException $e) {
                    $errors[] = 'Error deleting student: ' . $e->getMessage();
                }
            }
        }

        // 2. CREATE NEW STUDENT
        elseif ($postAction === 'create') {
            $name     = trim($_POST['name'] ?? '');
            $regno    = strtoupper(trim($_POST['register_number'] ?? ''));
            $email    = strtolower(trim($_POST['email'] ?? ''));
            $deptId   = (int)($_POST['department_id'] ?? 0);
            $year     = (int)($_POST['year_of_study'] ?? 1);
            $semId    = (int)($_POST['semester_id'] ?? 0);
            $password = $_POST['password'] ?? '';

            if ($name === '') $errors[] = 'Full name is required.';
            if ($regno === '') $errors[] = 'Register number is required.';
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'A valid college email is required.';
            if ($deptId <= 0) $errors[] = 'Please select a valid department.';
            if ($semId <= 0) $errors[] = 'Please select a valid semester.';
            if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';

            if (empty($errors)) {
                // Check uniqueness
                $dup = $pdo->prepare("SELECT id FROM `users` WHERE `email` = :em OR `register_number` = :reg LIMIT 1");
                $dup->execute(['em' => $email, 'reg' => $regno]);
                if ($dup->fetch()) {
                    $errors[] = 'A student with this email address or register number already exists.';
                } else {
                    try {
                        $pdo->beginTransaction();
                        $hash = password_hash($password, PASSWORD_BCRYPT);
                        $ins = $pdo->prepare("
                            INSERT INTO `users` (
                                `role`, `name`, `register_number`, `email`, 
                                `password_hash`, `department_id`, `year_of_study`, `semester_id`
                            ) VALUES (
                                'student', :name, :reg, :em, :hash, :dept, :yr, :sem
                            )
                        ");
                        $ins->execute([
                            'name' => $name, 'reg' => $regno, 'em' => $email,
                            'hash' => $hash, 'dept' => $deptId, 'yr' => $year, 'sem' => $semId,
                        ]);
                        $newId = (int)$pdo->lastInsertId();

                        // Auto-enroll in matching semester subjects
                        $subjStmt = $pdo->prepare("SELECT id FROM `subjects` WHERE `department_id` = :dept AND `semester_id` = :sem");
                        $subjStmt->execute(['dept' => $deptId, 'sem' => $semId]);
                        $subjectsList = $subjStmt->fetchAll();

                        $enStmt = $pdo->prepare("INSERT INTO `student_subjects` (`student_id`, `subject_id`) VALUES (:sid, :subjid)");
                        $attStmt = $pdo->prepare("INSERT INTO `attendance_records` (`student_id`, `subject_id`, `classes_conducted`, `classes_attended`) VALUES (:sid, :subjid, 0, 0)");

                        foreach ($subjectsList as $sb) {
                            $enStmt->execute(['sid' => $newId, 'subjid' => (int)$sb['id']]);
                            $attStmt->execute(['sid' => $newId, 'subjid' => (int)$sb['id']]);
                        }

                        $pdo->commit();
                        set_flash('success', "Student '$name' registered successfully.");
                        header('Location: students.php');
                        exit;
                    } catch (PDOException $e) {
                        $pdo->rollBack();
                        $errors[] = 'Database error: ' . $e->getMessage();
                    }
                }
            }
        }

        // 3. UPDATE EXISTING STUDENT
        elseif ($postAction === 'update') {
            $studentId = (int)($_POST['id'] ?? 0);
            $name      = trim($_POST['name'] ?? '');
            $regno     = strtoupper(trim($_POST['register_number'] ?? ''));
            $email     = strtolower(trim($_POST['email'] ?? ''));
            $deptId    = (int)($_POST['department_id'] ?? 0);
            $year      = (int)($_POST['year_of_study'] ?? 1);
            $semId     = (int)($_POST['semester_id'] ?? 0);
            $password  = $_POST['password'] ?? '';

            if ($studentId <= 0) $errors[] = 'Invalid student ID.';
            if ($name === '') $errors[] = 'Full name is required.';
            if ($regno === '') $errors[] = 'Register number is required.';
            if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) $errors[] = 'Valid email is required.';
            if ($deptId <= 0) $errors[] = 'Department is required.';
            if ($semId <= 0) $errors[] = 'Semester is required.';

            if (empty($errors)) {
                // Check duplicate excluding this student
                $dup = $pdo->prepare("SELECT id FROM `users` WHERE (`email` = :em OR `register_number` = :reg) AND id != :id LIMIT 1");
                $dup->execute(['em' => $email, 'reg' => $regno, 'id' => $studentId]);
                if ($dup->fetch()) {
                    $errors[] = 'Another user is already using this register number or email.';
                } else {
                    try {
                        if ($password !== '') {
                            if (strlen($password) < 6) {
                                $errors[] = 'New password must be at least 6 characters.';
                            } else {
                                $hash = password_hash($password, PASSWORD_BCRYPT);
                                $upd = $pdo->prepare("
                                    UPDATE `users` SET 
                                        `name` = :name, `register_number` = :reg, `email` = :em,
                                        `department_id` = :dept, `year_of_study` = :yr, `semester_id` = :sem,
                                        `password_hash` = :hash
                                    WHERE `id` = :id AND `role` = 'student'
                                ");
                                $upd->execute([
                                    'name' => $name, 'reg' => $regno, 'em' => $email,
                                    'dept' => $deptId, 'yr' => $year, 'sem' => $semId,
                                    'hash' => $hash, 'id' => $studentId,
                                ]);
                            }
                        } else {
                            $upd = $pdo->prepare("
                                UPDATE `users` SET 
                                    `name` = :name, `register_number` = :reg, `email` = :em,
                                    `department_id` = :dept, `year_of_study` = :yr, `semester_id` = :sem
                                WHERE `id` = :id AND `role` = 'student'
                            ");
                            $upd->execute([
                                'name' => $name, 'reg' => $regno, 'em' => $email,
                                'dept' => $deptId, 'yr' => $year, 'sem' => $semId,
                                'id' => $studentId,
                            ]);
                        }

                        if (empty($errors)) {
                            set_flash('success', "Student profile updated successfully.");
                            header('Location: students.php');
                            exit;
                        }
                    } catch (PDOException $e) {
                        $errors[] = 'Database error: ' . $e->getMessage();
                    }
                }
            }
        }
    }
}

// Fetch all students with department and semester names
$studentSql = "
    SELECT 
        u.*, 
        d.dept_code, 
        d.dept_name, 
        sem.semester_name,
        COUNT(DISTINCT ss.subject_id) AS enrolled_courses_count
    FROM `users` u
    LEFT JOIN `departments` d ON u.department_id = d.id
    LEFT JOIN `semesters` sem ON u.semester_id = sem.id
    LEFT JOIN `student_subjects` ss ON u.id = ss.student_id
    WHERE u.role = 'student'
";

if ($searchQuery !== '') {
    $studentSql .= " AND (u.name LIKE :q1 OR u.register_number LIKE :q2 OR u.email LIKE :q3)";
}

$studentSql .= " GROUP BY u.id ORDER BY u.register_number ASC";

$studentStmt = $pdo->prepare($studentSql);
if ($searchQuery !== '') {
    $param = '%' . $searchQuery . '%';
    $studentStmt->execute(['q1' => $param, 'q2' => $param, 'q3' => $param]);
} else {
    $studentStmt->execute();
}
$allStudents = $studentStmt->fetchAll();

$page_title = 'Student Directory';
$active_nav = 'admin_students';
require_once __DIR__ . '/../includes/header.php';
?>

<?php if (!empty($errors)): ?>
    <div class="alert alert-error">
        <span class="alert-icon">&#9888;</span>
        <div class="alert-content">
            <?php foreach ($errors as $err): ?>
                <div><?= e($err) ?></div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<!-- ADD / EDIT STUDENT MODAL / FORM SECTION -->
<div class="card">
    <div class="card-header">
        <div>
            <h3 class="card-title"><?= $editStudent ? 'Edit Student Profile' : 'Enroll New Student' ?></h3>
            <p class="card-subtitle"><?= $editStudent ? 'Modify student academic assignment and account details' : 'Register a student directly into the college database' ?></p>
        </div>
        <?php if ($editStudent): ?>
            <div class="card-actions">
                <a href="students.php" class="btn btn-secondary btn-sm">&times; Cancel Edit</a>
            </div>
        <?php endif; ?>
    </div>

    <div class="card-body">
        <form method="POST" action="students.php">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="<?= $editStudent ? 'update' : 'create' ?>">
            <?php if ($editStudent): ?>
                <input type="hidden" name="id" value="<?= (int)$editStudent['id'] ?>">
            <?php endif; ?>

            <div class="form-row">
                <div class="col">
                    <div class="form-group">
                        <label for="name">Full Name <span class="required">*</span></label>
                        <input type="text" id="name" name="name" class="form-control" 
                               placeholder="e.g. Maria Gonzalez" 
                               value="<?= e($editStudent ? $editStudent['name'] : ($_POST['name'] ?? '')) ?>" required>
                    </div>
                </div>

                <div class="col">
                    <div class="form-group">
                        <label for="register_number">Register Number <span class="required">*</span></label>
                        <input type="text" id="register_number" name="register_number" class="form-control" 
                               placeholder="e.g. REG2026CS110" 
                               value="<?= e($editStudent ? $editStudent['register_number'] : ($_POST['register_number'] ?? '')) ?>" required>
                    </div>
                </div>

                <div class="col">
                    <div class="form-group">
                        <label for="email">College Email <span class="required">*</span></label>
                        <input type="email" id="email" name="email" class="form-control" 
                               placeholder="e.g. maria@college.edu" 
                               value="<?= e($editStudent ? $editStudent['email'] : ($_POST['email'] ?? '')) ?>" required>
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="col">
                    <div class="form-group">
                        <label for="department_id">Department <span class="required">*</span></label>
                        <select id="department_id" name="department_id" class="form-control" required>
                            <option value="">-- Select Department --</option>
                            <?php foreach ($departments as $dept): 
                                $selected = $editStudent ? ((int)$editStudent['department_id'] === (int)$dept['id']) : false;
                            ?>
                                <option value="<?= (int)$dept['id'] ?>" <?= $selected ? 'selected' : '' ?>>
                                    <?= e($dept['dept_code']) ?> &mdash; <?= e($dept['dept_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="col">
                    <div class="form-group">
                        <label for="year_of_study">Year of Study <span class="required">*</span></label>
                        <select id="year_of_study" name="year_of_study" class="form-control" required>
                            <?php $curYr = $editStudent ? (int)$editStudent['year_of_study'] : 1; ?>
                            <option value="1" <?= ($curYr === 1) ? 'selected' : '' ?>>1st Year</option>
                            <option value="2" <?= ($curYr === 2) ? 'selected' : '' ?>>2nd Year</option>
                            <option value="3" <?= ($curYr === 3) ? 'selected' : '' ?>>3rd Year</option>
                            <option value="4" <?= ($curYr === 4) ? 'selected' : '' ?>>4th Year</option>
                        </select>
                    </div>
                </div>

                <div class="col">
                    <div class="form-group">
                        <label for="semester_id">Semester <span class="required">*</span></label>
                        <select id="semester_id" name="semester_id" class="form-control" required>
                            <option value="">-- Select Semester --</option>
                            <?php foreach ($semesters as $sem): 
                                $selected = $editStudent ? ((int)$editStudent['semester_id'] === (int)$sem['id']) : false;
                            ?>
                                <option value="<?= (int)$sem['id'] ?>" <?= $selected ? 'selected' : '' ?>>
                                    <?= e($sem['semester_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="col">
                    <div class="form-group">
                        <label for="password"><?= $editStudent ? 'Reset Password (optional)' : 'Initial Password *' ?></label>
                        <input type="password" id="password" name="password" class="form-control" 
                               placeholder="<?= $editStudent ? 'Leave blank to keep current' : 'Min 6 characters' ?>" 
                               <?= $editStudent ? '' : 'required' ?>>
                    </div>
                </div>
            </div>

            <div style="margin-top: 0.5rem;">
                <button type="submit" class="btn btn-primary">
                    <?= $editStudent ? '&#10004; Save Changes' : '+ Register Student' ?>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- ALL REGISTERED STUDENTS TABLE -->
<div class="card">
    <div class="card-header">
        <div>
            <h3 class="card-title">Enrolled Students Roster</h3>
            <p class="card-subtitle">Total of <?= count($allStudents) ?> registered student accounts</p>
        </div>
        <div class="card-actions">
            <form method="GET" action="students.php" style="display: flex; gap: 0.5rem;">
                <input type="text" name="q" class="form-control" style="width: 220px; padding: 0.35rem 0.65rem; font-size: 0.85rem;" 
                       placeholder="Filter by name / reg no..." value="<?= e($searchQuery) ?>">
                <button type="submit" class="btn btn-secondary btn-sm">&#128269; Filter</button>
                <?php if ($searchQuery !== ''): ?>
                    <a href="students.php" class="btn btn-secondary btn-sm">Clear</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="card-body" style="padding: 0;">
        <?php if (empty($allStudents)): ?>
            <div class="empty-state">
                <div class="empty-icon">&#127891;</div>
                <h4 class="empty-title">No Students Found</h4>
                <p class="empty-description">Use the form above to enroll your first student or clear your search filter.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Student</th>
                            <th>Register Number</th>
                            <th>Department</th>
                            <th>Academic Year / Sem</th>
                            <th style="text-align: center;">Enrolled Courses</th>
                            <th style="text-align: right;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($allStudents as $st): ?>
                            <tr>
                                <td>
                                    <div style="font-weight: 700; color: #0f172a;"><?= e($st['name']) ?></div>
                                    <div style="font-size: 0.775rem; color: #64748b;"><?= e($st['email']) ?></div>
                                </td>
                                <td style="font-weight: 700; color: #1e3a8a;"><?= e($st['register_number'] ?? 'N/A') ?></td>
                                <td><?= e($st['dept_code'] ?? 'None') ?></td>
                                <td>Year <?= e($st['year_of_study'] ?? '1') ?> &bull; <?= e($st['semester_name'] ?? 'N/A') ?></td>
                                <td style="text-align: center;">
                                    <span class="badge badge-slate"><?= (int)$st['enrolled_courses_count'] ?> Courses</span>
                                </td>
                                <td style="text-align: right; white-space: nowrap;">
                                    <a href="manage_attendance.php?student_id=<?= (int)$st['id'] ?>" class="btn btn-secondary btn-sm" title="Manage Attendance">
                                        &#9997; Attendance
                                    </a>
                                    <a href="students.php?edit=<?= (int)$st['id'] ?>" class="btn btn-secondary btn-sm" title="Edit Student Profile">
                                        Edit
                                    </a>
                                    <form method="POST" action="students.php" style="display: inline;">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= (int)$st['id'] ?>">
                                        <button type="submit" class="btn btn-secondary btn-sm" style="color: #dc2626;">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
