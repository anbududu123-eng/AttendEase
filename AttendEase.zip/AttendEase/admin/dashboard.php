<?php
/**
 * AttendEase — Administrator Dashboard
 * Module 9: Institutional Overview, Summary Metrics, Shortage Monitoring & Student Search
 */

declare(strict_types=1);

$base_path = '../';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$pdo = get_db_connection();

// Student search query parameter
$searchQuery = trim($_GET['q'] ?? '');

// Real Database Aggregations
// 1. Total registered students
$totalStudents = (int)$pdo->query("SELECT COUNT(*) FROM `users` WHERE `role` = 'student'")->fetchColumn();

// 2. Total active subjects
$totalSubjects = (int)$pdo->query("SELECT COUNT(*) FROM `subjects`")->fetchColumn();

// 3. Total departments
$totalDepartments = (int)$pdo->query("SELECT COUNT(*) FROM `departments`")->fetchColumn();

// 4. Overall campus attendance percentage
$campusTotals = $pdo->query("
    SELECT 
        COALESCE(SUM(classes_conducted), 0) AS total_conducted,
        COALESCE(SUM(classes_attended), 0) AS total_attended
    FROM `attendance_records`
")->fetch();

$campusConducted = (int)($campusTotals['total_conducted'] ?? 0);
$campusAttended  = (int)($campusTotals['total_attended'] ?? 0);
$campusAvgPct    = calculate_percentage($campusAttended, $campusConducted);

// 5. Query all student attendance records with shortage across the college
$shortageSql = "
    SELECT 
        u.id AS student_id,
        u.name AS student_name,
        u.register_number,
        u.email AS student_email,
        d.dept_code,
        sem.semester_name,
        s.id AS subject_id,
        s.subject_code,
        s.subject_name,
        s.required_percentage,
        ar.classes_conducted,
        ar.classes_attended
    FROM `attendance_records` ar
    INNER JOIN `users` u ON ar.student_id = u.id
    INNER JOIN `subjects` s ON ar.subject_id = s.id
    LEFT JOIN `departments` d ON u.department_id = d.id
    LEFT JOIN `semesters` sem ON u.semester_id = sem.id
    WHERE u.role = 'student' 
      AND ar.classes_conducted > 0 
      AND (ar.classes_attended / ar.classes_conducted * 100.0) < s.required_percentage
";

if ($searchQuery !== '') {
    $shortageSql .= " AND (u.name LIKE :q1 OR u.register_number LIKE :q2)";
}

$shortageSql .= " ORDER BY u.register_number ASC, s.subject_code ASC";

$shortageStmt = $pdo->prepare($shortageSql);
if ($searchQuery !== '') {
    $param = '%' . $searchQuery . '%';
    $shortageStmt->execute(['q1' => $param, 'q2' => $param]);
} else {
    $shortageStmt->execute();
}
$shortageRecords = $shortageStmt->fetchAll();

// Unique count of students with shortage
$uniqueShortageStudents = [];
foreach ($shortageRecords as $sr) {
    $uniqueShortageStudents[$sr['student_id']] = true;
}
$shortageStudentsCount = count($uniqueShortageStudents);

$page_title = 'Administrator Dashboard';
$active_nav = 'admin_dashboard';
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Search Bar for Students -->
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-body" style="padding: 1.25rem 1.5rem;">
        <form method="GET" action="dashboard.php" style="display: flex; flex-wrap: wrap; gap: 0.75rem; align-items: center;">
            <label for="search-input" style="font-weight: 700; font-size: 0.9rem; color: #0f172a;">Search Student Directory:</label>
            <input type="text" id="search-input" name="q" class="form-control" 
                   style="flex: 1; min-width: 260px;" 
                   placeholder="Enter Register Number or Student Name..." 
                   value="<?= e($searchQuery) ?>">
            <button type="submit" class="btn btn-primary">&#128269; Search</button>
            <?php if ($searchQuery !== ''): ?>
                <a href="dashboard.php" class="btn btn-secondary">Clear</a>
            <?php endif; ?>
        </form>
    </div>
</div>

<!-- Admin Key Performance Indicators -->
<div class="stats-grid">
    <div class="stat-card stat-primary">
        <div class="stat-header">
            <span class="stat-title">Registered Students</span>
            <div class="stat-icon">&#127891;</div>
        </div>
        <div class="stat-value"><?= $totalStudents ?></div>
        <div class="stat-footer">Active student accounts</div>
    </div>

    <div class="stat-card stat-safe">
        <div class="stat-header">
            <span class="stat-title">Campus Average Attendance</span>
            <div class="stat-icon">&#128200;</div>
        </div>
        <div class="stat-value"><?= number_format($campusAvgPct, 2) ?>%</div>
        <div class="stat-footer"><?= $campusAttended ?> / <?= $campusConducted ?> total lecture hours</div>
    </div>

    <div class="stat-card <?= ($shortageStudentsCount > 0) ? 'stat-shortage' : 'stat-safe' ?>">
        <div class="stat-header">
            <span class="stat-title">Students in Shortage</span>
            <div class="stat-icon">&#9888;</div>
        </div>
        <div class="stat-value"><?= $shortageStudentsCount ?></div>
        <div class="stat-footer">Requiring official recovery attention</div>
    </div>

    <div class="stat-card stat-neutral">
        <div class="stat-header">
            <span class="stat-title">Catalog Subjects</span>
            <div class="stat-icon">&#128218;</div>
        </div>
        <div class="stat-value"><?= $totalSubjects ?></div>
        <div class="stat-footer">Across <?= $totalDepartments ?> Academic Departments</div>
    </div>
</div>

<!-- Institutional Attendance Shortage Roster -->
<div class="card card-highlight-shortage">
    <div class="card-header">
        <div>
            <h3 class="card-title">&#9888; Campus-Wide Attendance Shortage Monitor</h3>
            <p class="card-subtitle">Students whose attendance in one or more courses is below regulatory requirements</p>
        </div>
        <div class="card-actions">
            <a href="manage_attendance.php" class="btn btn-secondary btn-sm">&#9997; Manage Attendance</a>
            <a href="students.php" class="btn btn-secondary btn-sm">&#127891; View Students</a>
        </div>
    </div>

    <div class="card-body" style="padding: 0;">
        <?php if (empty($shortageRecords)): ?>
            <div class="empty-state">
                <div class="empty-icon">&#10004;</div>
                <h4 class="empty-title">Zero Shortage Identified</h4>
                <p class="empty-description">
                    <?= ($searchQuery !== '') ? 'No shortage records matched your search query.' : 'All enrolled students currently meet or exceed their required course percentages.' ?>
                </p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Student Name</th>
                            <th>Register No</th>
                            <th>Dept / Sem</th>
                            <th>Course Name</th>
                            <th style="text-align: center;">Conducted</th>
                            <th style="text-align: center;">Attended</th>
                            <th style="text-align: center;">Current %</th>
                            <th style="text-align: center;">Required %</th>
                            <th style="text-align: center;">Recovery Classes</th>
                            <th style="text-align: right;">Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($shortageRecords as $rec): 
                            $c = (int)$rec['classes_conducted'];
                            $a = (int)$rec['classes_attended'];
                            $req = (float)$rec['required_percentage'];
                            $calc = calculate_shortage($a, $c, $req);
                        ?>
                            <tr class="row-shortage">
                                <td style="font-weight: 700; color: #0f172a;">
                                    <?= e($rec['student_name']) ?>
                                    <div style="font-size: 0.75rem; color: #64748b; font-weight: normal;"><?= e($rec['student_email']) ?></div>
                                </td>
                                <td style="font-weight: 700; color: #1e3a8a;"><?= e($rec['register_number'] ?? 'N/A') ?></td>
                                <td><?= e($rec['dept_code'] ?? '') ?> &bull; <?= e($rec['semester_name'] ?? '') ?></td>
                                <td>
                                    <strong><?= e($rec['subject_code']) ?></strong>
                                    <div style="font-size: 0.8rem; color: #475569;"><?= e($rec['subject_name']) ?></div>
                                </td>
                                <td style="text-align: center; font-weight: 600;"><?= $c ?></td>
                                <td style="text-align: center; font-weight: 600; color: #065f46;"><?= $a ?></td>
                                <td style="text-align: center; font-weight: 800; color: #991b1b;">
                                    <?= number_format($calc['current_percentage'], 2) ?>%
                                </td>
                                <td style="text-align: center; font-weight: 600;"><?= number_format($req, 1) ?>%</td>
                                <td style="text-align: center;">
                                    <?php if ($calc['is_impossible_100']): ?>
                                        <span style="font-size: 0.75rem; font-weight: 700; color: #991b1b;">100% Unachievable</span>
                                    <?php else: ?>
                                        <span style="font-size: 1.05rem; font-weight: 800; color: #991b1b;">
                                            +<?= $calc['classes_needed'] ?>
                                        </span>
                                        <div style="font-size: 0.7rem; color: #7f1d1d;">classes needed</div>
                                    <?php endif; ?>
                                </td>
                                <td style="text-align: right;">
                                    <a href="manage_attendance.php?student_id=<?= (int)$rec['student_id'] ?>&subject_id=<?= (int)$rec['subject_id'] ?>" 
                                       class="btn btn-secondary btn-sm">
                                        Update
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
