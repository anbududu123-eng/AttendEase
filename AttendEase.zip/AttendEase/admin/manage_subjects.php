<?php
/**
 * AttendEase — Administrator: Subject Management
 * Module 3 & 9: Create, Edit, Configure Attendance Requirements, and Delete Subjects
 */

declare(strict_types=1);

$base_path = '../';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$pdo = get_db_connection();

$departments = $pdo->query("SELECT * FROM `departments` ORDER BY `dept_name` ASC")->fetchAll();
$semesters   = $pdo->query("SELECT * FROM `semesters` ORDER BY `semester_number` ASC")->fetchAll();

$errors = [];
$editSubject = null;
$editId = (int)($_GET['edit'] ?? 0);

if ($editId > 0) {
    $editStmt = $pdo->prepare("SELECT * FROM `subjects` WHERE id = :id LIMIT 1");
    $editStmt->execute(['id' => $editId]);
    $editSubject = $editStmt->fetch();
}

// Handle Form Submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid session token. Please try again.';
    } else {
        $postAction = $_POST['action'] ?? '';

        // 1. DELETE SUBJECT
        if ($postAction === 'delete') {
            $deleteId = (int)($_POST['id'] ?? 0);
            if ($deleteId > 0) {
                try {
                    $delStmt = $pdo->prepare("DELETE FROM `subjects` WHERE id = :id");
                    $delStmt->execute(['id' => $deleteId]);
                    set_flash('success', 'Subject removed from catalog successfully.');
                    header('Location: manage_subjects.php');
                    exit;
                } catch (PDOException $e) {
                    $errors[] = 'Error deleting subject: ' . $e->getMessage();
                }
            }
        }

        // 2. CREATE NEW SUBJECT
        elseif ($postAction === 'create') {
            $code    = strtoupper(trim($_POST['subject_code'] ?? ''));
            $name    = trim($_POST['subject_name'] ?? '');
            $faculty = trim($_POST['faculty_name'] ?? '');
            $deptId  = (int)($_POST['department_id'] ?? 0);
            $semId   = (int)($_POST['semester_id'] ?? 0);
            $reqPct  = (float)($_POST['required_percentage'] ?? 75.0);

            if ($code === '') $errors[] = 'Subject code is required.';
            if ($name === '') $errors[] = 'Subject name is required.';
            if ($faculty === '') $errors[] = 'Faculty name is required.';
            if ($deptId <= 0) $errors[] = 'Department is required.';
            if ($semId <= 0) $errors[] = 'Semester is required.';
            if ($reqPct <= 0 || $reqPct > 100) $errors[] = 'Required percentage must be between 1 and 100%.';

            if (empty($errors)) {
                // Check duplicate subject code in department & semester
                $dup = $pdo->prepare("SELECT id FROM `subjects` WHERE `department_id` = :dept AND `semester_id` = :sem AND `subject_code` = :code LIMIT 1");
                $dup->execute(['dept' => $deptId, 'sem' => $semId, 'code' => $code]);
                if ($dup->fetch()) {
                    $errors[] = "Subject code '$code' is already registered for this department and semester.";
                } else {
                    try {
                        $ins = $pdo->prepare("
                            INSERT INTO `subjects` (
                                `subject_code`, `subject_name`, `faculty_name`, 
                                `department_id`, `semester_id`, `required_percentage`
                            ) VALUES (
                                :code, :name, :faculty, :dept, :sem, :req
                            )
                        ");
                        $ins->execute([
                            'code'    => $code,
                            'name'    => $name,
                            'faculty' => $faculty,
                            'dept'    => $deptId,
                            'sem'     => $semId,
                            'req'     => $reqPct,
                        ]);

                        set_flash('success', "Subject '$code - $name' added successfully with {$reqPct}% requirement.");
                        header('Location: manage_subjects.php');
                        exit;
                    } catch (PDOException $e) {
                        $errors[] = 'Database error: ' . $e->getMessage();
                    }
                }
            }
        }

        // 3. UPDATE EXISTING SUBJECT
        elseif ($postAction === 'update') {
            $subjId  = (int)($_POST['id'] ?? 0);
            $code    = strtoupper(trim($_POST['subject_code'] ?? ''));
            $name    = trim($_POST['subject_name'] ?? '');
            $faculty = trim($_POST['faculty_name'] ?? '');
            $deptId  = (int)($_POST['department_id'] ?? 0);
            $semId   = (int)($_POST['semester_id'] ?? 0);
            $reqPct  = (float)($_POST['required_percentage'] ?? 75.0);

            if ($subjId <= 0) $errors[] = 'Invalid subject ID.';
            if ($code === '') $errors[] = 'Subject code is required.';
            if ($name === '') $errors[] = 'Subject name is required.';
            if ($faculty === '') $errors[] = 'Faculty name is required.';
            if ($deptId <= 0) $errors[] = 'Department is required.';
            if ($semId <= 0) $errors[] = 'Semester is required.';
            if ($reqPct <= 0 || $reqPct > 100) $errors[] = 'Required percentage must be between 1 and 100%.';

            if (empty($errors)) {
                $dup = $pdo->prepare("SELECT id FROM `subjects` WHERE `department_id` = :dept AND `semester_id` = :sem AND `subject_code` = :code AND id != :id LIMIT 1");
                $dup->execute(['dept' => $deptId, 'sem' => $semId, 'code' => $code, 'id' => $subjId]);
                if ($dup->fetch()) {
                    $errors[] = "Subject code '$code' already exists for this department and semester.";
                } else {
                    try {
                        $upd = $pdo->prepare("
                            UPDATE `subjects` SET 
                                `subject_code` = :code,
                                `subject_name` = :name,
                                `faculty_name` = :faculty,
                                `department_id` = :dept,
                                `semester_id` = :sem,
                                `required_percentage` = :req
                            WHERE id = :id
                        ");
                        $upd->execute([
                            'code'    => $code,
                            'name'    => $name,
                            'faculty' => $faculty,
                            'dept'    => $deptId,
                            'sem'     => $semId,
                            'req'     => $reqPct,
                            'id'      => $subjId,
                        ]);

                        set_flash('success', "Subject details updated successfully.");
                        header('Location: manage_subjects.php');
                        exit;
                    } catch (PDOException $e) {
                        $errors[] = 'Database error: ' . $e->getMessage();
                    }
                }
            }
        }
    }
}

// Fetch all subjects with department, semester, and enrolled student counts
$subjectsList = $pdo->query("
    SELECT 
        s.*, 
        d.dept_code, 
        d.dept_name, 
        sem.semester_name,
        COUNT(DISTINCT ss.student_id) AS enrolled_students_count,
        COALESCE(AVG(CASE WHEN ar.classes_conducted > 0 THEN (ar.classes_attended / ar.classes_conducted * 100) ELSE NULL END), 0) AS avg_attendance
    FROM `subjects` s
    INNER JOIN `departments` d ON s.department_id = d.id
    INNER JOIN `semesters` sem ON s.semester_id = sem.id
    LEFT JOIN `student_subjects` ss ON s.id = ss.subject_id
    LEFT JOIN `attendance_records` ar ON s.id = ar.subject_id
    GROUP BY s.id
    ORDER BY d.dept_code ASC, sem.semester_number ASC, s.subject_code ASC
")->fetchAll();

$page_title = 'Manage Subjects';
$active_nav = 'admin_subjects';
require_once __DIR__ . '/../includes/header.php';
?>

<?php if (!empty($errors)): ?>
    <div class="alert alert-error">
        <span class="alert-icon">&#9888;</span>
        <div class="alert-content">
            <?php foreach ($errors as $err): ?>
                <div><?= e($err) ?></div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<!-- CREATE OR EDIT SUBJECT FORM -->
<div class="card">
    <div class="card-header">
        <div>
            <h3 class="card-title"><?= $editSubject ? 'Edit Subject Details' : 'Add New Subject' ?></h3>
            <p class="card-subtitle"><?= $editSubject ? 'Configure course properties and attendance percentage requirement' : 'Add an academic course to the institutional catalog' ?></p>
        </div>
        <?php if ($editSubject): ?>
            <div class="card-actions">
                <a href="manage_subjects.php" class="btn btn-secondary btn-sm">&times; Cancel Edit</a>
            </div>
        <?php endif; ?>
    </div>

    <div class="card-body">
        <form method="POST" action="manage_subjects.php">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="<?= $editSubject ? 'update' : 'create' ?>">
            <?php if ($editSubject): ?>
                <input type="hidden" name="id" value="<?= (int)$editSubject['id'] ?>">
            <?php endif; ?>

            <div class="form-row">
                <div class="col" style="flex: 1;">
                    <div class="form-group">
                        <label for="subject_code">Subject Code <span class="required">*</span></label>
                        <input type="text" id="subject_code" name="subject_code" class="form-control" 
                               placeholder="e.g. CS501" 
                               value="<?= e($editSubject ? $editSubject['subject_code'] : ($_POST['subject_code'] ?? '')) ?>" required>
                    </div>
                </div>

                <div class="col" style="flex: 2;">
                    <div class="form-group">
                        <label for="subject_name">Subject Name <span class="required">*</span></label>
                        <input type="text" id="subject_name" name="subject_name" class="form-control" 
                               placeholder="e.g. Database Management Systems" 
                               value="<?= e($editSubject ? $editSubject['subject_name'] : ($_POST['subject_name'] ?? '')) ?>" required>
                    </div>
                </div>

                <div class="col" style="flex: 2;">
                    <div class="form-group">
                        <label for="faculty_name">Faculty / Instructor Name <span class="required">*</span></label>
                        <input type="text" id="faculty_name" name="faculty_name" class="form-control" 
                               placeholder="e.g. Dr. Edgar Codd" 
                               value="<?= e($editSubject ? $editSubject['faculty_name'] : ($_POST['faculty_name'] ?? '')) ?>" required>
                    </div>
                </div>
            </div>

            <div class="form-row">
                <div class="col">
                    <div class="form-group">
                        <label for="department_id">Department <span class="required">*</span></label>
                        <select id="department_id" name="department_id" class="form-control" required>
                            <option value="">-- Select Department --</option>
                            <?php foreach ($departments as $dept): 
                                $selected = $editSubject ? ((int)$editSubject['department_id'] === (int)$dept['id']) : false;
                            ?>
                                <option value="<?= (int)$dept['id'] ?>" <?= $selected ? 'selected' : '' ?>>
                                    <?= e($dept['dept_code']) ?> &mdash; <?= e($dept['dept_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="col">
                    <div class="form-group">
                        <label for="semester_id">Semester <span class="required">*</span></label>
                        <select id="semester_id" name="semester_id" class="form-control" required>
                            <option value="">-- Select Semester --</option>
                            <?php foreach ($semesters as $sem): 
                                $selected = $editSubject ? ((int)$editSubject['semester_id'] === (int)$sem['id']) : false;
                            ?>
                                <option value="<?= (int)$sem['id'] ?>" <?= $selected ? 'selected' : '' ?>>
                                    <?= e($sem['semester_name']) ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="col">
                    <div class="form-group">
                        <label for="required_percentage">Required Attendance % <span class="required">*</span></label>
                        <input type="number" id="required_percentage" name="required_percentage" class="form-control" 
                               step="0.5" min="1" max="100" 
                               value="<?= e($editSubject ? $editSubject['required_percentage'] : ($_POST['required_percentage'] ?? '75.0')) ?>" required>
                        <div class="form-help">Default is 75%, adjustable per institutional policy</div>
                    </div>
                </div>
            </div>

            <div style="margin-top: 0.5rem;">
                <button type="submit" class="btn btn-primary">
                    <?= $editSubject ? '&#10004; Update Subject' : '+ Create Subject' ?>
                </button>
            </div>
        </form>
    </div>
</div>

<!-- SUBJECTS DIRECTORY TABLE -->
<div class="card">
    <div class="card-header">
        <div>
            <h3 class="card-title">Subject Catalog & Requirements</h3>
            <p class="card-subtitle">Showing <?= count($subjectsList) ?> configured academic subjects</p>
        </div>
    </div>

    <div class="card-body" style="padding: 0;">
        <?php if (empty($subjectsList)): ?>
            <div class="empty-state">
                <div class="empty-icon">&#128218;</div>
                <h4 class="empty-title">Catalog is Empty</h4>
                <p class="empty-description">Create your first subject using the form above.</p>
            </div>
        <?php else: ?>
            <div class="table-responsive">
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>Code</th>
                            <th>Course Name</th>
                            <th>Faculty</th>
                            <th>Department</th>
                            <th>Semester</th>
                            <th style="text-align: center;">Required %</th>
                            <th style="text-align: center;">Enrolled Students</th>
                            <th style="text-align: center;">Avg Attendance</th>
                            <th style="text-align: right;">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($subjectsList as $sb): ?>
                            <tr>
                                <td style="font-weight: 700; color: #1e3a8a;"><?= e($sb['subject_code']) ?></td>
                                <td style="font-weight: 600;"><?= e($sb['subject_name']) ?></td>
                                <td><?= e($sb['faculty_name']) ?></td>
                                <td><?= e($sb['dept_code']) ?></td>
                                <td><?= e($sb['semester_name']) ?></td>
                                <td style="text-align: center; font-weight: 700; color: #1e3a8a;">
                                    <?= number_format((float)$sb['required_percentage'], 1) ?>%
                                </td>
                                <td style="text-align: center;">
                                    <span class="badge badge-slate"><?= (int)$sb['enrolled_students_count'] ?></span>
                                </td>
                                <td style="text-align: center; font-weight: 600;">
                                    <?= number_format((float)$sb['avg_attendance'], 2) ?>%
                                </td>
                                <td style="text-align: right; white-space: nowrap;">
                                    <a href="manage_subjects.php?edit=<?= (int)$sb['id'] ?>" class="btn btn-secondary btn-sm">Edit</a>
                                    <form method="POST" action="manage_subjects.php" style="display: inline;">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="action" value="delete">
                                        <input type="hidden" name="id" value="<?= (int)$sb['id'] ?>">
                                        <button type="submit" class="btn btn-secondary btn-sm" style="color: #dc2626;">Delete</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
