<?php
/**
 * AttendEase — Administrator: Manage Attendance
 * Module 4 & 9: Record, Audit, and Correct Student Attendance Records
 */

declare(strict_types=1);

$base_path = '../';
require_once __DIR__ . '/../includes/auth.php';

require_admin();

$pdo = get_db_connection();

$errors = [];

// Fetch all students for selector dropdown
$allStudents = $pdo->query("
    SELECT u.id, u.name, u.register_number, d.dept_code, sem.semester_name 
    FROM `users` u
    LEFT JOIN `departments` d ON u.department_id = d.id
    LEFT JOIN `semesters` sem ON u.semester_id = sem.id
    WHERE u.role = 'student'
    ORDER BY u.register_number ASC
")->fetchAll();

$selectedStudentId = (int)($_GET['student_id'] ?? ($_POST['student_id'] ?? 0));
if ($selectedStudentId === 0 && !empty($allStudents)) {
    $selectedStudentId = (int)$allStudents[0]['id'];
}

// Handle Form Submission for Single Subject Attendance Update
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verify_csrf_token($_POST['csrf_token'] ?? '')) {
        $errors[] = 'Invalid session token. Please try again.';
    } else {
        $studentId = (int)($_POST['student_id'] ?? 0);
        $subjectId = (int)($_POST['subject_id'] ?? 0);
        $conducted = trim($_POST['classes_conducted'] ?? '');
        $attended  = trim($_POST['classes_attended'] ?? '');

        if (!ctype_digit($conducted) || !ctype_digit($attended)) {
            $errors[] = 'Conducted and attended classes must be positive integers.';
        } else {
            $c = (int)$conducted;
            $a = (int)$attended;

            if ($c < 0 || $a < 0) {
                $errors[] = 'Values cannot be negative.';
            } elseif ($a > $c) {
                $errors[] = "Validation Error: Classes attended ($a) cannot exceed classes conducted ($c).";
            } else {
                try {
                    $stmt = $pdo->prepare("
                        INSERT INTO `attendance_records` (
                            `student_id`, `subject_id`, `classes_conducted`, `classes_attended`, `last_updated`
                        ) VALUES (
                            :sid, :subjid, :c, :a, NOW()
                        )
                        ON DUPLICATE KEY UPDATE 
                            `classes_conducted` = :c2,
                            `classes_attended` = :a2,
                            `last_updated` = NOW()
                    ");
                    $stmt->execute([
                        'sid'    => $studentId,
                        'subjid' => $subjectId,
                        'c'      => $c,
                        'a'      => $a,
                        'c2'     => $c,
                        'a2'     => $a,
                    ]);

                    set_flash('success', 'Attendance record updated successfully.');
                    header('Location: manage_attendance.php?student_id=' . $studentId);
                    exit;
                } catch (PDOException $e) {
                    $errors[] = 'Database error while saving attendance: ' . $e->getMessage();
                }
            }
        }
    }
}

// Fetch selected student profile
$studentStmt = $pdo->prepare("
    SELECT u.*, d.dept_name, d.dept_code, sem.semester_name 
    FROM `users` u
    LEFT JOIN `departments` d ON u.department_id = d.id
    LEFT JOIN `semesters` sem ON u.semester_id = sem.id
    WHERE u.id = :id AND u.role = 'student'
    LIMIT 1
");
$studentStmt->execute(['id' => $selectedStudentId]);
$targetStudent = $studentStmt->fetch();

// Fetch enrolled subjects & attendance for this student
$studentCourses = [];
if ($targetStudent) {
    $courseStmt = $pdo->prepare("
        SELECT 
            s.id AS subject_id,
            s.subject_code,
            s.subject_name,
            s.faculty_name,
            s.required_percentage,
            COALESCE(ar.classes_conducted, 0) AS classes_conducted,
            COALESCE(ar.classes_attended, 0) AS classes_attended,
            ar.last_updated
        FROM `student_subjects` ss
        INNER JOIN `subjects` s ON ss.subject_id = s.id
        LEFT JOIN `attendance_records` ar ON ar.student_id = :sid AND ar.subject_id = s.id
        WHERE ss.student_id = :sid2
        ORDER BY s.subject_code ASC
    ");
    $courseStmt->execute(['sid' => $selectedStudentId, 'sid2' => $selectedStudentId]);
    $studentCourses = $courseStmt->fetchAll();
}

$editSubjId = (int)($_GET['edit_subject'] ?? 0);

$page_title = 'Manage Attendance';
$active_nav = 'admin_attendance';
require_once __DIR__ . '/../includes/header.php';
?>

<!-- Student Selector Card -->
<div class="card" style="margin-bottom: 1.5rem;">
    <div class="card-body" style="padding: 1.25rem 1.5rem;">
        <form method="GET" action="manage_attendance.php" style="display: flex; flex-wrap: wrap; gap: 1rem; align-items: center;">
            <label for="student_id" style="font-weight: 700; font-size: 0.9rem; color: #0f172a;">Select Student to Audit:</label>
            <select id="student_id" name="student_id" class="form-control" style="flex: 1; min-width: 280px;">
                <?php foreach ($allStudents as $st): ?>
                    <option value="<?= (int)$st['id'] ?>" <?= ((int)$st['id'] === $selectedStudentId) ? 'selected' : '' ?>>
                        <?= e($st['register_number'] ?? 'N/A') ?> &mdash; <?= e($st['name']) ?> (<?= e($st['dept_code'] ?? '') ?> - <?= e($st['semester_name'] ?? '') ?>)
                    </option>
                <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-primary btn-sm">Load Attendance Sheet</button>
        </form>
    </div>
</div>

<?php if (!empty($errors)): ?>
    <div class="alert alert-error">
        <span class="alert-icon">&#9888;</span>
        <div class="alert-content">
            <?php foreach ($errors as $err): ?>
                <div><?= e($err) ?></div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<?php if ($targetStudent): ?>
    <!-- Target Student Academic Header Banner -->
    <div class="card" style="margin-bottom: 1.5rem;">
        <div class="card-body" style="padding: 1.25rem 1.5rem;">
            <div style="display: flex; flex-wrap: wrap; justify-content: space-between; align-items: center; gap: 1rem;">
                <div>
                    <h3 style="font-size: 1.25rem; font-weight: 800; color: #0f172a; margin-bottom: 0.2rem;">
                        <?= e($targetStudent['name']) ?>
                    </h3>
                    <div style="font-size: 0.85rem; color: #64748b;">
                        <span>Register No: <strong><?= e($targetStudent['register_number'] ?? 'N/A') ?></strong></span> &bull; 
                        <span>Department: <strong><?= e($targetStudent['dept_name'] ?? 'N/A') ?> (<?= e($targetStudent['dept_code'] ?? '') ?>)</strong></span> &bull; 
                        <span>Academic: <strong><?= e($targetStudent['year_of_study'] ?? '1') ?> Year &bull; <?= e($targetStudent['semester_name'] ?? 'N/A') ?></strong></span>
                    </div>
                </div>
                <div>
                    <a href="students.php?edit=<?= (int)$targetStudent['id'] ?>" class="btn btn-secondary btn-sm">Edit Profile</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Attendance Table -->
    <div class="card">
        <div class="card-header">
            <div>
                <h3 class="card-title">Course Attendance Records</h3>
                <p class="card-subtitle">Directly edit conducted and attended classes for regulatory compliance</p>
            </div>
        </div>

        <div class="card-body" style="padding: 0;">
            <?php if (empty($studentCourses)): ?>
                <div class="empty-state">
                    <div class="empty-icon">&#128218;</div>
                    <h4 class="empty-title">No Enrolled Courses</h4>
                    <p class="empty-description">This student has not been enrolled in any courses for their semester.</p>
                </div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="data-table">
                        <thead>
                            <tr>
                                <th>Subject Code & Name</th>
                                <th>Faculty</th>
                                <th style="text-align: center;">Conducted</th>
                                <th style="text-align: center;">Attended</th>
                                <th style="text-align: center;">Absent</th>
                                <th style="text-align: center;">Percentage</th>
                                <th style="text-align: center;">Required %</th>
                                <th>Status</th>
                                <th style="text-align: right; width: 150px;">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($studentCourses as $row): 
                                $c = (int)$row['classes_conducted'];
                                $a = (int)$row['classes_attended'];
                                $req = (float)$row['required_percentage'];
                                $absent = max(0, $c - $a);
                                $pct = calculate_percentage($a, $c);
                                $status = get_attendance_status($a, $c, $req);
                                $isEditing = ($editSubjId === (int)$row['subject_id']);
                            ?>
                                <tr class="<?= ($status === 'SHORTAGE') ? 'row-shortage' : '' ?>">
                                    <td>
                                        <div class="subject-info">
                                            <span class="subject-name"><?= e($row['subject_name']) ?></span>
                                            <span class="subject-meta">Code: <strong><?= e($row['subject_code']) ?></strong></span>
                                        </div>
                                    </td>
                                    <td><?= e($row['faculty_name']) ?></td>

                                    <?php if ($isEditing): ?>
                                        <td colspan="7" style="background-color: #f8fafc; padding: 1rem;">
                                            <form method="POST" action="manage_attendance.php" style="display: flex; flex-wrap: wrap; align-items: center; justify-content: flex-end; gap: 1rem;">
                                                <?= csrf_field() ?>
                                                <input type="hidden" name="student_id" value="<?= $selectedStudentId ?>">
                                                <input type="hidden" name="subject_id" value="<?= (int)$row['subject_id'] ?>">

                                                <div style="display: flex; align-items: center; gap: 0.5rem;">
                                                    <label for="c_val" style="font-size: 0.825rem; font-weight: 600;">Conducted:</label>
                                                    <input type="number" id="c_val" name="classes_conducted" class="form-control" 
                                                           style="width: 85px; text-align: center;" value="<?= $c ?>" min="0" required>
                                                </div>

                                                <div style="display: flex; align-items: center; gap: 0.5rem;">
                                                    <label for="a_val" style="font-size: 0.825rem; font-weight: 600;">Attended:</label>
                                                    <input type="number" id="a_val" name="classes_attended" class="form-control" 
                                                           style="width: 85px; text-align: center;" value="<?= $a ?>" min="0" required>
                                                </div>

                                                <div style="display: flex; gap: 0.5rem;">
                                                    <button type="submit" class="btn btn-success btn-sm">&#10004; Save</button>
                                                    <a href="manage_attendance.php?student_id=<?= $selectedStudentId ?>" class="btn btn-secondary btn-sm">Cancel</a>
                                                </div>
                                            </form>
                                        </td>
                                    <?php else: ?>
                                        <td style="text-align: center; font-weight: 700;"><?= $c ?></td>
                                        <td style="text-align: center; font-weight: 700; color: #065f46;"><?= $a ?></td>
                                        <td style="text-align: center; font-weight: 600; color: #991b1b;"><?= $absent ?></td>
                                        <td style="text-align: center; font-weight: 800; color: <?= ($status === 'SAFE') ? '#065f46' : (($status === 'SHORTAGE') ? '#991b1b' : '#64748b') ?>;">
                                            <?= number_format($pct, 2) ?>%
                                        </td>
                                        <td style="text-align: center; font-weight: 600;"><?= number_format($req, 1) ?>%</td>
                                        <td>
                                            <?php if ($status === 'SAFE'): ?>
                                                <span class="badge badge-safe">&#10004; SAFE</span>
                                            <?php elseif ($status === 'SHORTAGE'): ?>
                                                <span class="badge badge-shortage">&#9888; SHORTAGE</span>
                                            <?php else: ?>
                                                <span class="badge badge-neutral">&#9711; NO CLASSES</span>
                                            <?php endif; ?>
                                        </td>
                                        <td style="text-align: right;">
                                            <a href="manage_attendance.php?student_id=<?= $selectedStudentId ?>&edit_subject=<?= (int)$row['subject_id'] ?>" 
                                               class="btn btn-secondary btn-sm">
                                                &#9997; Edit Record
                                            </a>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
<?php endif; ?>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>
